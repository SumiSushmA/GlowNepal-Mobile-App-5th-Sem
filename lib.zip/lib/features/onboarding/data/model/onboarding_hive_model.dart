import 'package:hive/hive.dart';

part 'onboarding_hive_model.g.dart';

@HiveType(typeId: 1)
class OnboardingHiveModel {
  @HiveField(0)
  final bool onboardingSeen;

  OnboardingHiveModel({required this.onboardingSeen});
}
