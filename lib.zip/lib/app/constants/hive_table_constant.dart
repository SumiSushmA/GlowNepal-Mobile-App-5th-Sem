class HiveTableConstant {
  HiveTableConstant._();

  static const int loginTableId = 0;
  static const String loginBox = 'loginBox';

  static const int signupTableId = 1;
  static const String signupBox = 'signupBox';
}
