import 'package:glownepal_mobile_app_5th_sem/features/onboarding/domain/repository/onboarding_repository.dart';

class SetOnboardingSeenUseCase {
  final OnboardingRepository repository;

  SetOnboardingSeenUseCase(this.repository);

  Future<void> call() async {
    await repository.setOnboardingSeen();
  }
}
