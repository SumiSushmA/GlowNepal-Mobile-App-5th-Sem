import 'package:glownepal_mobile_app_5th_sem/features/authentication/data/data_source/login_datasource.dart';
import 'package:hive_flutter/hive_flutter.dart';

class LoginLocalDataSource implements ILoginDataSource {
  final Box box;

  LoginLocalDataSource(this.box);

  @override
  Future<void> cacheUserData(
      String token, Map<String, dynamic> userData) async {
    await box.put('token', token);
    await box.put('userData', userData);
  }

  @override
  Future<String?> getCachedToken() async {
    return box.get('token');
  }

  @override
  Future<Map<String, dynamic>?> getCachedUserData() async {
    return box.get('userData');
  }

  @override
  Future<Map<String, dynamic>> authenticateUser(String email, String password) {
    throw UnimplementedError("Local data source cannot authenticate user");
  }
}
