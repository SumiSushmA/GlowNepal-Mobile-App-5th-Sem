import '../../domain/entity/signup_entity.dart';
import '../../domain/repository/signup_repository.dart';
import '../data_source/signup_datasource.dart';

class SignupLocalRepository implements SignupRepository {
  final ISignupDataSource localDataSource;

  SignupLocalRepository(this.localDataSource);

  @override
  Future<void> saveUserSession(String token, SignupEntity user) async {
    await localDataSource.cacheUserData(token, user.toMap());
  }

  @override
  Future<SignupEntity?> getCachedUserSession() async {
    final token = await localDataSource.getCachedToken();
    final userData = await localDataSource.getCachedUserData();

    if (token != null && userData != null) {
      return SignupEntity(token: token, userData: userData);
    }
    return null;
  }

  @override
  Future<Map<String, dynamic>> registerUser(
      String name, String email, String password, String imagePath) {
    throw UnimplementedError("Local repository cannot register user");
  }
}
