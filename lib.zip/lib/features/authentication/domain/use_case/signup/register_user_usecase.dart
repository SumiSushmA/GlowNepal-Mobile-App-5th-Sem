// import 'package:glownepal_mobile_app_5th_sem/features/authentication/domain/entity/signup_entity.dart';
// import 'package:glownepal_mobile_app_5th_sem/features/authentication/domain/repository/signup_repository.dart';

// class RegisterUserUseCase {
//   final SignupRepository remoteRepository;
//   final SignupRepository localRepository;

//   RegisterUserUseCase(
//       {required this.remoteRepository, required this.localRepository, required signupRepository});

//   Future<SignupEntity> register(
//       String name, String email, String password, String imagePath) async {
//     final response =
//         await remoteRepository.registerUser(name, email, password, imagePath);

//     final token = response['token'];
//     final userData = response['user'];

//     final userEntity = SignupEntity(token: token, userData: userData);
//     await localRepository.saveUserSession(token, userEntity);

//     return userEntity;
//   }
// }

import 'package:glownepal_mobile_app_5th_sem/features/authentication/domain/entity/signup_entity.dart';
import 'package:glownepal_mobile_app_5th_sem/features/authentication/domain/repository/signup_repository.dart';

class RegisterUserUseCase {
  final SignupRepository localRepository;

  RegisterUserUseCase({required this.localRepository});

  Future<SignupEntity> register(
      String name, String email, String password, String imagePath) async {
    // Use the local repository to register the user
    final response = await localRepository.registerUser(
      name,
      email,
      password,
      imagePath,
    );

    // Extract token and user data
    final token = response['token'];
    final userData = response['user'];

    // Create a SignupEntity
    final userEntity = SignupEntity(token: token, userData: userData);

    // Save user session in the local repository
    await localRepository.saveUserSession(token, userEntity);

    return userEntity;
  }
}
