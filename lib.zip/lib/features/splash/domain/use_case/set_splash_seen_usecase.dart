import 'package:glownepal_mobile_app_5th_sem/features/splash/domain/repository/splash_repository.dart';

class SetSplashSeenUseCase {
  final SplashRepository repository;

  SetSplashSeenUseCase(this.repository);

  Future<void> call() async {
    await repository.setSplashSeen();
  }
}
