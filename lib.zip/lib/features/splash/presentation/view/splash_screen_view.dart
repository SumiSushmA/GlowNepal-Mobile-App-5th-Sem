// import 'package:flutter/material.dart';
// import 'package:flutter_bloc/flutter_bloc.dart';
// import 'package:glownepal_mobile_app_5th_sem/features/onboarding/presentation/view/onboarding_screen_view.dart';
// import 'package:glownepal_mobile_app_5th_sem/features/splash/domain/use_case/check_splash_seen_usecase.dart';
// import 'package:glownepal_mobile_app_5th_sem/features/splash/domain/use_case/set_splash_seen_usecase.dart';
// import 'package:glownepal_mobile_app_5th_sem/features/splash/presentation/view_model/splash/splash_bloc.dart';
// import 'package:glownepal_mobile_app_5th_sem/features/splash/presentation/view_model/splash/splash_event.dart';
// import 'package:glownepal_mobile_app_5th_sem/features/splash/presentation/view_model/splash/splash_state.dart';

// class SplashScreenView extends StatelessWidget {
//   const SplashScreenView({super.key});

//   @override
//   Widget build(BuildContext context) {
//     return BlocProvider(
//       create: (context) => SplashBloc(
//         CheckSplashSeenUseCase(context.read()),
//         SetSplashSeenUseCase(context.read()),
//       )..add(CheckSplashSeenEvent()),
//       child: Scaffold(
//         body: BlocListener<SplashBloc, SplashState>(
//           listener: (context, state) {
//             if (state is SplashSeen) {
//               Navigator.pushReplacement(
//                 context,
//                 MaterialPageRoute(
//                   builder: (context) => OnboardingScreenView(),
//                 ),
//               );
//             }
//           },
//           child: Center(
//             child: Text(
//               "GlowNepal",
//               style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
//             ),
//           ),
//         ),
//       ),
//     );
//   }
// }

import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:glownepal_mobile_app_5th_sem/features/onboarding/presentation/view/onboarding_screen_view.dart';
import 'package:glownepal_mobile_app_5th_sem/features/splash/presentation/view_model/splash/splash_bloc.dart';
import 'package:glownepal_mobile_app_5th_sem/features/splash/presentation/view_model/splash/splash_state.dart';

class SplashScreenView extends StatelessWidget {
  const SplashScreenView({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: BlocListener<SplashBloc, SplashState>(
        listener: (context, state) {
          if (state is SplashSeen) {
            Navigator.pushReplacement(
              context,
              MaterialPageRoute(
                builder: (context) => OnboardingScreenView(),
              ),
            );
          } else if (state is SplashNotSeen) {
            Navigator.pushReplacement(
              context,
              MaterialPageRoute(
                builder: (context) => OnboardingScreenView(),
              ),
            );
          }
        },
        child: Center(
          child: Text(
            "GlowNepal",
            style: TextStyle(
              fontSize: 24,
              fontWeight: FontWeight.bold,
            ),
          ),
        ),
      ),
    );
  }
}
