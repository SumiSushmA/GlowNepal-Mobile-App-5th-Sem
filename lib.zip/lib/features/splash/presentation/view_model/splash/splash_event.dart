abstract class SplashEvent {}

class CheckSplashSeenEvent extends SplashEvent {}

class SetSplashSeenEvent extends SplashEvent {}
