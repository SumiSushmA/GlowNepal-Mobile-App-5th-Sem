// import 'package:glownepal_mobile_app_5th_sem/features/authentication/domain/entity/login_entity.dart';
// import 'package:glownepal_mobile_app_5th_sem/features/authentication/domain/repository/login_repository.dart';

// class AuthenticateUserUseCase {
//   final LoginRepository remoteRepository;
//   final LoginRepository localRepository;

//   AuthenticateUserUseCase({
//     required this.remoteRepository,
//     required this.localRepository,
//   });

//   Future<LoginEntity> authenticate(String email, String password) async {
//     final response = await remoteRepository.authenticateUser(email, password);

//     final token = response['token'];
//     final userData = response['user'];

//     final userEntity = LoginEntity(token: token, userData: userData);
//     await localRepository.saveUserSession(token, userEntity);

//     return userEntity;
//   }
// }

import 'package:glownepal_mobile_app_5th_sem/features/authentication/domain/entity/login_entity.dart';
import 'package:glownepal_mobile_app_5th_sem/features/authentication/domain/repository/login_repository.dart';

class AuthenticateUserUseCase {
  final LoginRepository localRepository;

  AuthenticateUserUseCase({
    required this.localRepository,
  });

  Future<LoginEntity> authenticate(String email, String password) async {
    // Fetch user data from the local repository
    final response = await localRepository.authenticateUser(email, password);

    // Extract token and user data
    final token = response['token'];
    final userData = response['user'];

    // Create a LoginEntity
    final userEntity = LoginEntity(token: token, userData: userData);

    // Save user session in local repository
    await localRepository.saveUserSession(token, userEntity);

    return userEntity;
  }
}
