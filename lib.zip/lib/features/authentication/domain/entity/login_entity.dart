class LoginEntity {
  final String token;
  final Map<String, dynamic> userData;

  LoginEntity({required this.token, required this.userData});

  Map<String, dynamic> toMap() {
    return {
      'token': token,
      'userData': userData,
    };
  }

  factory LoginEntity.fromMap(Map<String, dynamic> map) {
    return LoginEntity(
      token: map['token'],
      userData: map['userData'],
    );
  }
}
