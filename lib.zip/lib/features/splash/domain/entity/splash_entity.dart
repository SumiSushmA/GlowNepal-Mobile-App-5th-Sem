class SplashEntity {
  final bool splashSeen;

  SplashEntity({required this.splashSeen});
}
