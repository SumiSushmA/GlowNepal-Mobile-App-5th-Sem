import 'package:glownepal_mobile_app_5th_sem/features/authentication/domain/entity/login_entity.dart';

abstract class LoginRepository {
  Future<void> saveUserSession(String token, LoginEntity user);
  Future<LoginEntity?> getCachedUserSession();
  Future<Map<String, dynamic>> authenticateUser(String email, String password);
}
