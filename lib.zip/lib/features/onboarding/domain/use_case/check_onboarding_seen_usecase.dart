import 'package:glownepal_mobile_app_5th_sem/features/onboarding/domain/repository/onboarding_repository.dart';

class CheckOnboardingSeenUseCase {
  final OnboardingRepository repository;

  CheckOnboardingSeenUseCase(this.repository);

  Future<bool> call() async {
    return await repository.isOnboardingSeen();
  }
}
