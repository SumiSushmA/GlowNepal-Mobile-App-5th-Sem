import 'package:hive/hive.dart';

class OnboardingLocalDataSource {
  final Box box;

  OnboardingLocalDataSource(this.box);

  Future<bool> isOnboardingSeen() async {
    return box.get('onboarding_seen', defaultValue: false);
  }

  Future<void> setOnboardingSeen() async {
    await box.put('onboarding_seen', true);
  }
}
