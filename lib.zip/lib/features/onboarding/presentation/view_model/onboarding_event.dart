abstract class OnboardingEvent {}

class CheckOnboardingSeenEvent extends OnboardingEvent {}

class SetOnboardingSeenEvent extends OnboardingEvent {}
