import 'package:hive/hive.dart';

part 'signup_hive_model.g.dart';

@HiveType(typeId: 3)
class SignupHiveModel {
  @HiveField(0)
  final String token;

  @HiveField(1)
  final Map<String, dynamic> userData;

  SignupHiveModel({required this.token, required this.userData});
}
