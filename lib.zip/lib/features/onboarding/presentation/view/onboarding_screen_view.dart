import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:glownepal_mobile_app_5th_sem/features/authentication/presentation/view/login/login_screen_view.dart';
import 'package:glownepal_mobile_app_5th_sem/features/onboarding/domain/use_case/check_onboarding_seen_usecase.dart';
import 'package:glownepal_mobile_app_5th_sem/features/onboarding/domain/use_case/set_onboarding_seen_usecase.dart';
import 'package:glownepal_mobile_app_5th_sem/features/onboarding/presentation/view_model/onboarding_bloc.dart';
import 'package:glownepal_mobile_app_5th_sem/features/onboarding/presentation/view_model/onboarding_event.dart';
import 'package:glownepal_mobile_app_5th_sem/features/onboarding/presentation/view_model/onboarding_state.dart';

class OnboardingScreenView extends StatelessWidget {
  final List<Map<String, String>> onboardingData = [
    {
      "image": "assets/images/onboarding1.jpg",
      "title": "✨ Welcome to GlowNepal! ✨",
      "description": "Your Beauty and Salon Experience, Simplified!"
    },
    {
      "image": "assets/images/onboarding2.jpg",
      "title": "Discover Salons and Services 🏠💖",
      "description":
          "Find a wide range of salons and beauty services near you. Whether it’s a haircut, manicure, or facial, explore the best options around."
    },
    {
      "image": "assets/images/onboarding3.jpg",
      "title": "Easy Appointment Booking 📅✨",
      "description":
          "Book your next beauty treatment in just a few taps. It's that simple!"
    },
  ];

  OnboardingScreenView({super.key});

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (context) => OnboardingBloc(
        CheckOnboardingSeenUseCase(context.read()),
        SetOnboardingSeenUseCase(context.read()),
      )..add(CheckOnboardingSeenEvent()),
      child: Scaffold(
        body: BlocListener<OnboardingBloc, OnboardingState>(
          listener: (context, state) {
            if (state is OnboardingSeen) {
              Navigator.pushReplacement(
                context,
                MaterialPageRoute(
                  builder: (context) => LoginScreenView(),
                ),
              );
            }
          },
          child: OnboardingUI(onboardingData: onboardingData),
        ),
      ),
    );
  }
}

class OnboardingUI extends StatefulWidget {
  final List<Map<String, String>> onboardingData;

  const OnboardingUI({super.key, required this.onboardingData});

  @override
  State<OnboardingUI> createState() => _OnboardingUIState();
}

class _OnboardingUIState extends State<OnboardingUI> {
  final PageController _controller = PageController();
  int _currentIndex = 0;

  void _goToNextPage() {
    if (_currentIndex == widget.onboardingData.length - 1) {
      context.read<OnboardingBloc>().add(SetOnboardingSeenEvent());
    } else {
      _controller.nextPage(
        duration: const Duration(milliseconds: 300),
        curve: Curves.easeInOut,
      );
    }
  }

  void _skipToLastPage() {
    _controller.jumpToPage(widget.onboardingData.length - 1);
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        // PageView for Onboarding Content
        PageView.builder(
          controller: _controller,
          onPageChanged: (index) {
            setState(() {
              _currentIndex = index;
            });
          },
          itemCount: widget.onboardingData.length,
          itemBuilder: (context, index) {
            final data = widget.onboardingData[index];
            return Stack(
              fit: StackFit.expand,
              children: [
                Image.asset(
                  data['image']!,
                  fit: BoxFit.cover,
                ),
                Positioned(
                  bottom: 150,
                  left: 20,
                  right: 20,
                  child: Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: Colors.black.withOpacity(0.5),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text(
                          data['title']!,
                          style: const TextStyle(
                            fontSize: 28,
                            fontWeight: FontWeight.bold,
                            color: Colors.white,
                          ),
                          textAlign: TextAlign.center,
                        ),
                        const SizedBox(height: 10),
                        Text(
                          data['description']!,
                          style: const TextStyle(
                            fontSize: 18,
                            color: Colors.white,
                          ),
                          textAlign: TextAlign.center,
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            );
          },
        ),

        // Skip Button
        Positioned(
          top: 40,
          right: 20,
          child: TextButton(
            onPressed: _skipToLastPage,
            child: const Text(
              "Skip",
              style: TextStyle(
                color: Colors.white,
                fontSize: 16,
              ),
            ),
          ),
        ),

        // Dots Indicator and Next Button
        Positioned(
          bottom: 20,
          left: 20,
          right: 20,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              // Dots Indicator
              Row(
                children: List.generate(
                  widget.onboardingData.length,
                  (index) => Container(
                    margin: const EdgeInsets.symmetric(horizontal: 4),
                    width: 8,
                    height: 8,
                    decoration: BoxDecoration(
                      color: _currentIndex == index ? Colors.pink : Colors.grey,
                      shape: BoxShape.circle,
                    ),
                  ),
                ),
              ),

              // Next or Get Started Button
              TextButton(
                onPressed: _goToNextPage,
                child: Text(
                  _currentIndex == widget.onboardingData.length - 1
                      ? "Get Started"
                      : "Next",
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 16,
                  ),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}
