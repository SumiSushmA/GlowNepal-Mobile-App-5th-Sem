import 'package:glownepal_mobile_app_5th_sem/features/onboarding/data/data_source/local_datasource/onboarding_local_datasource.dart';
import 'package:glownepal_mobile_app_5th_sem/features/onboarding/domain/repository/onboarding_repository.dart';

class OnboardingLocalRepository implements OnboardingRepository {
  final OnboardingLocalDataSource localDataSource;

  OnboardingLocalRepository(this.localDataSource);

  @override
  Future<bool> isOnboardingSeen() async {
    return await localDataSource.isOnboardingSeen();
  }

  @override
  Future<void> setOnboardingSeen() async {
    await localDataSource.setOnboardingSeen();
  }
}
