import 'package:glownepal_mobile_app_5th_sem/features/splash/data/data_source/local_datasource/splash_local_datasource.dart';
import 'package:glownepal_mobile_app_5th_sem/features/splash/domain/repository/splash_repository.dart';

class SplashLocalRepository implements SplashRepository {
  final SplashLocalDataSource localDataSource;

  SplashLocalRepository(this.localDataSource);

  @override
  Future<bool> isSplashSeen() async {
    return await localDataSource.isSplashSeen();
  }

  @override
  Future<void> setSplashSeen() async {
    await localDataSource.setSplashSeen();
  }
}
