import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:glownepal_mobile_app_5th_sem/features/onboarding/domain/use_case/check_onboarding_seen_usecase.dart';
import 'package:glownepal_mobile_app_5th_sem/features/onboarding/domain/use_case/set_onboarding_seen_usecase.dart';

import 'onboarding_event.dart';
import 'onboarding_state.dart';

class OnboardingBloc extends Bloc<OnboardingEvent, OnboardingState> {
  final CheckOnboardingSeenUseCase checkOnboardingSeenUseCase;
  final SetOnboardingSeenUseCase setOnboardingSeenUseCase;

  OnboardingBloc(this.checkOnboardingSeenUseCase, this.setOnboardingSeenUseCase)
      : super(OnboardingInitial()) {
    on<CheckOnboardingSeenEvent>((event, emit) async {
      final seen = await checkOnboardingSeenUseCase();
      if (seen) {
        emit(OnboardingSeen());
      } else {
        emit(OnboardingNotSeen());
      }
    });

    on<SetOnboardingSeenEvent>((event, emit) async {
      await setOnboardingSeenUseCase();
      emit(OnboardingSeen());
    });
  }
}
