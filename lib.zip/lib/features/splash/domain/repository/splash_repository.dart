abstract class SplashRepository {
  Future<bool> isSplashSeen();
  Future<void> setSplashSeen();
}
