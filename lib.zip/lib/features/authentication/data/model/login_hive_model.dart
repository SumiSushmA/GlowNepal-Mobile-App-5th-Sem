import 'package:hive/hive.dart';

part 'login_hive_model.g.dart';

@HiveType(typeId: 2)
class LoginHiveModel {
  @HiveField(0)
  final String token;

  @HiveField(1)
  final Map<String, dynamic> userData;

  LoginHiveModel({required this.token, required this.userData});
}
