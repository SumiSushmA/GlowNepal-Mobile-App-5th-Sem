import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:glownepal_mobile_app_5th_sem/features/authentication/domain/use_case/login/authenticate_user_usecase.dart';

import 'login_event.dart';
import 'login_state.dart';

class LoginBloc extends Bloc<LoginEvent, LoginState> {
  final AuthenticateUserUseCase authenticateUserUseCase;

  LoginBloc(this.authenticateUserUseCase) : super(LoginInitial()) {
    on<LoginSubmitted>((event, emit) async {
      emit(LoginLoading());
      try {
        final user = await authenticateUserUseCase.authenticate(
            event.email, event.password);
        emit(LoginSuccess(user: user));
      } catch (e) {
        emit(LoginFailure(message: e.toString()));
      }
    });
  }
}
