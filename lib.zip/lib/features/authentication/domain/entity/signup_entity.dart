class SignupEntity {
  final String token;
  final Map<String, dynamic> userData;

  SignupEntity({required this.token, required this.userData});

  Map<String, dynamic> toMap() {
    return {
      'token': token,
      'userData': userData,
    };
  }

  factory SignupEntity.fromMap(Map<String, dynamic> map) {
    return SignupEntity(
      token: map['token'],
      userData: map['userData'],
    );
  }
}
