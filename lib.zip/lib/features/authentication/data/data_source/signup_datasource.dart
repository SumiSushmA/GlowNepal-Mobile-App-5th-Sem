abstract class ISignupDataSource {
  Future<Map<String, dynamic>> registerUser(
    String name,
    String email,
    String password,
    String imagePath,
  );
  Future<void> cacheUserData(String token, Map<String, dynamic> userData);
  Future<String?> getCachedToken();
  Future<Map<String, dynamic>?> getCachedUserData();
}
