import 'package:glownepal_mobile_app_5th_sem/features/authentication/domain/entity/signup_entity.dart';

abstract class SignupRepository {
  Future<void> saveUserSession(String token, SignupEntity user);
  Future<SignupEntity?> getCachedUserSession();
  Future<Map<String, dynamic>> registerUser(
      String name, String email, String password, String imagePath);
}
