abstract class SplashState {}

class SplashInitial extends SplashState {}

class SplashSeen extends SplashState {}

class SplashNotSeen extends SplashState {}
