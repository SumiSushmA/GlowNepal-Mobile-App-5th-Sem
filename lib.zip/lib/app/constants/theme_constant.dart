import 'package:flutter/material.dart';

class ThemeConstant {
  ThemeConstant._();
  static const Color darkPrimaryColor = Colors.pink;
  static const Color primaryColor = Colors.deepPurple;
  static const Color appBarColor = Colors.deepPurpleAccent;
}
