import 'package:glownepal_mobile_app_5th_sem/features/splash/domain/repository/splash_repository.dart';

class CheckSplashSeenUseCase {
  final SplashRepository repository;

  CheckSplashSeenUseCase(this.repository);

  Future<bool> call() async {
    return await repository.isSplashSeen();
  }
}
