import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:glownepal_mobile_app_5th_sem/features/authentication/domain/use_case/signup/register_user_usecase.dart';

import 'signup_event.dart';
import 'signup_state.dart';

class SignupBloc extends Bloc<SignupEvent, SignupState> {
  final RegisterUserUseCase registerUserUseCase;

  SignupBloc(this.registerUserUseCase) : super(SignupInitial()) {
    on<SignupSubmitted>((event, emit) async {
      emit(SignupLoading());
      try {
        final user = await registerUserUseCase.register(
            event.name, event.email, event.password, event.imagePath);
        emit(SignupSuccess(user: user));
      } catch (e) {
        emit(SignupFailure(message: e.toString()));
      }
    });
  }
}
