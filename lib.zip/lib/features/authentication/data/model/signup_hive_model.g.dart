// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'signup_hive_model.dart';

// **************************************************************************
// TypeAdapterGenerator
// **************************************************************************

class SignupHiveModelAdapter extends TypeAdapter<SignupHiveModel> {
  @override
  final int typeId = 3;

  @override
  SignupHiveModel read(BinaryReader reader) {
    final numOfFields = reader.readByte();
    final fields = <int, dynamic>{
      for (int i = 0; i < numOfFields; i++) reader.readByte(): reader.read(),
    };
    return SignupHiveModel(
      token: fields[0] as String,
      userData: (fields[1] as Map).cast<String, dynamic>(),
    );
  }

  @override
  void write(BinaryWriter writer, SignupHiveModel obj) {
    writer
      ..writeByte(2)
      ..writeByte(0)
      ..write(obj.token)
      ..writeByte(1)
      ..write(obj.userData);
  }

  @override
  int get hashCode => typeId.hashCode;

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is SignupHiveModelAdapter &&
          runtimeType == other.runtimeType &&
          typeId == other.typeId;
}
