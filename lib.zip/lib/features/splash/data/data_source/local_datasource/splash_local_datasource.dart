import 'package:hive/hive.dart';

class SplashLocalDataSource {
  final Box box;

  SplashLocalDataSource(this.box);

  Future<bool> isSplashSeen() async {
    return box.get('splash_seen', defaultValue: false);
  }

  Future<void> setSplashSeen() async {
    await box.put('splash_seen', true);
  }
}
