// import 'package:get_it/get_it.dart';
// import 'package:glownepal_mobile_app_5th_sem/core/network/hive_service.dart';
// import 'package:glownepal_mobile_app_5th_sem/features/authentication/data/data_source/local_datasource/login_local_datasource.dart';
// import 'package:glownepal_mobile_app_5th_sem/features/authentication/data/data_source/local_datasource/signup_local_datasource.dart';
// import 'package:glownepal_mobile_app_5th_sem/features/authentication/data/repository/login_local_repository.dart';
// import 'package:glownepal_mobile_app_5th_sem/features/authentication/data/repository/signup_local_repository.dart';
// import 'package:glownepal_mobile_app_5th_sem/features/authentication/domain/use_case/login/authenticate_user_usecase.dart';
// import 'package:glownepal_mobile_app_5th_sem/features/authentication/domain/use_case/signup/register_user_usecase.dart';
// import 'package:glownepal_mobile_app_5th_sem/features/authentication/presentation/view_model/login/login_bloc.dart';
// import 'package:glownepal_mobile_app_5th_sem/features/authentication/presentation/view_model/signup/signup_bloc.dart';
// import 'package:glownepal_mobile_app_5th_sem/features/onboarding/data/data_source/local_datasource/onboarding_local_datasource.dart';
// import 'package:glownepal_mobile_app_5th_sem/features/onboarding/data/repository/onboarding_local_repository.dart';
// import 'package:glownepal_mobile_app_5th_sem/features/onboarding/domain/use_case/check_onboarding_seen_usecase.dart';
// import 'package:glownepal_mobile_app_5th_sem/features/onboarding/domain/use_case/set_onboarding_seen_usecase.dart';
// import 'package:glownepal_mobile_app_5th_sem/features/onboarding/presentation/view_model/onboarding_bloc.dart';
// import 'package:glownepal_mobile_app_5th_sem/features/splash/data/data_source/local_datasource/splash_local_datasource.dart';
// import 'package:glownepal_mobile_app_5th_sem/features/splash/data/repository/splash_local_repository.dart';
// import 'package:glownepal_mobile_app_5th_sem/features/splash/domain/use_case/check_splash_seen_usecase.dart';
// import 'package:glownepal_mobile_app_5th_sem/features/splash/domain/use_case/set_splash_seen_usecase.dart';
// import 'package:glownepal_mobile_app_5th_sem/features/splash/presentation/view_model/splash/splash_bloc.dart';
// import 'package:hive_flutter/hive_flutter.dart';

// final getIt = GetIt.instance;

// Future<void> initDependencies() async {
//   _initHiveService();
//   _initSplashDependencies();
//   _initOnboardingDependencies();
//   _initLoginDependencies();
//   _initSignupDependencies();
// }

// void _initHiveService() {
//   getIt.registerLazySingleton<HiveService>(() => HiveService());
// }

// void _initSplashDependencies() {
//   // Data Source
//   getIt.registerLazySingleton<SplashLocalDataSource>(
//       () => SplashLocalDataSource(getIt<HiveService>() as Box));

//   // Repository
//   getIt.registerLazySingleton<SplashLocalRepository>(
//       () => SplashLocalRepository(getIt<SplashLocalDataSource>()));

//   // Use Cases
//   getIt.registerLazySingleton<CheckSplashSeenUseCase>(
//       () => CheckSplashSeenUseCase(getIt<SplashLocalRepository>()));
//   getIt.registerLazySingleton<SetSplashSeenUseCase>(
//       () => SetSplashSeenUseCase(getIt<SplashLocalRepository>()));

//   // Bloc
//   getIt.registerFactory<SplashBloc>(
//     () => SplashBloc(
//       getIt<CheckSplashSeenUseCase>(),
//       getIt<SetSplashSeenUseCase>(),
//     ),
//   );
// }

// void _initOnboardingDependencies() {
//   // Data Source
//   getIt.registerLazySingleton<OnboardingLocalDataSource>(
//       () => OnboardingLocalDataSource(getIt<HiveService>() as Box));

//   // Repository
//   getIt.registerLazySingleton<OnboardingLocalRepository>(
//       () => OnboardingLocalRepository(getIt<OnboardingLocalDataSource>()));

//   // Use Cases
//   getIt.registerLazySingleton<CheckOnboardingSeenUseCase>(
//       () => CheckOnboardingSeenUseCase(getIt<OnboardingLocalRepository>()));
//   getIt.registerLazySingleton<SetOnboardingSeenUseCase>(
//       () => SetOnboardingSeenUseCase(getIt<OnboardingLocalRepository>()));

//   // Bloc
//   getIt.registerFactory<OnboardingBloc>(
//     () => OnboardingBloc(
//       getIt<CheckOnboardingSeenUseCase>(),
//       getIt<SetOnboardingSeenUseCase>(),
//     ),
//   );
// }

// void _initLoginDependencies() {
//   // Data Source
//   getIt.registerLazySingleton<LoginLocalDataSource>(
//       () => LoginLocalDataSource(getIt<HiveService>() as Box));

//   // Repository
//   getIt.registerLazySingleton<LoginLocalRepository>(
//       () => LoginLocalRepository(getIt<LoginLocalDataSource>()));

//   // Use Case
//   getIt.registerLazySingleton<AuthenticateUserUseCase>(() =>
//       AuthenticateUserUseCase(localRepository: getIt<LoginLocalRepository>()));

//   // Bloc
//   getIt.registerFactory<LoginBloc>(
//     () => LoginBloc(getIt<AuthenticateUserUseCase>()),
//   );
// }

// void _initSignupDependencies() {
//   // Data Source
//   getIt.registerLazySingleton<SignupLocalDataSource>(
//       () => SignupLocalDataSource(getIt<HiveService>() as Box));

//   // Repository
//   getIt.registerLazySingleton<SignupLocalRepository>(
//       () => SignupLocalRepository(getIt<SignupLocalDataSource>()));

//   // Use Case
//   getIt.registerLazySingleton<RegisterUserUseCase>(() =>
//       RegisterUserUseCase(localRepository: getIt<SignupLocalRepository>()));

//   // Bloc
//   getIt.registerFactory<SignupBloc>(
//     () => SignupBloc(getIt<RegisterUserUseCase>()),
//   );
// }

import 'package:get_it/get_it.dart';
import 'package:glownepal_mobile_app_5th_sem/core/network/hive_service.dart';
import 'package:glownepal_mobile_app_5th_sem/features/authentication/data/data_source/local_datasource/login_local_datasource.dart';
import 'package:glownepal_mobile_app_5th_sem/features/authentication/data/data_source/local_datasource/signup_local_datasource.dart';
import 'package:glownepal_mobile_app_5th_sem/features/authentication/data/repository/login_local_repository.dart';
import 'package:glownepal_mobile_app_5th_sem/features/authentication/data/repository/signup_local_repository.dart';
import 'package:glownepal_mobile_app_5th_sem/features/authentication/domain/use_case/login/authenticate_user_usecase.dart';
import 'package:glownepal_mobile_app_5th_sem/features/authentication/domain/use_case/signup/register_user_usecase.dart';
import 'package:glownepal_mobile_app_5th_sem/features/authentication/presentation/view_model/login/login_bloc.dart';
import 'package:glownepal_mobile_app_5th_sem/features/authentication/presentation/view_model/signup/signup_bloc.dart';
import 'package:glownepal_mobile_app_5th_sem/features/onboarding/data/data_source/local_datasource/onboarding_local_datasource.dart';
import 'package:glownepal_mobile_app_5th_sem/features/onboarding/data/repository/onboarding_local_repository.dart';
import 'package:glownepal_mobile_app_5th_sem/features/onboarding/domain/use_case/check_onboarding_seen_usecase.dart';
import 'package:glownepal_mobile_app_5th_sem/features/onboarding/domain/use_case/set_onboarding_seen_usecase.dart';
import 'package:glownepal_mobile_app_5th_sem/features/onboarding/presentation/view_model/onboarding_bloc.dart';
import 'package:glownepal_mobile_app_5th_sem/features/splash/data/data_source/local_datasource/splash_local_datasource.dart';
import 'package:glownepal_mobile_app_5th_sem/features/splash/data/repository/splash_local_repository.dart';
import 'package:glownepal_mobile_app_5th_sem/features/splash/domain/use_case/check_splash_seen_usecase.dart';
import 'package:glownepal_mobile_app_5th_sem/features/splash/domain/use_case/set_splash_seen_usecase.dart';
import 'package:glownepal_mobile_app_5th_sem/features/splash/presentation/view_model/splash/splash_bloc.dart';

final getIt = GetIt.instance;

Future<void> initDependencies() async {
  _initHiveService();
  _initSplashDependencies();
  _initOnboardingDependencies();
  _initLoginDependencies();
  _initSignupDependencies();
}

void _initHiveService() {
  getIt.registerLazySingleton<HiveService>(() => HiveService());
}

void _initSplashDependencies() {
  final splashBox = getIt<HiveService>().getBox('splashBox');

  getIt.registerLazySingleton<SplashLocalDataSource>(
      () => SplashLocalDataSource(splashBox));

  getIt.registerLazySingleton<SplashLocalRepository>(
      () => SplashLocalRepository(getIt<SplashLocalDataSource>()));

  getIt.registerLazySingleton<CheckSplashSeenUseCase>(
      () => CheckSplashSeenUseCase(getIt<SplashLocalRepository>()));
  getIt.registerLazySingleton<SetSplashSeenUseCase>(
      () => SetSplashSeenUseCase(getIt<SplashLocalRepository>()));

  getIt.registerFactory<SplashBloc>(
    () => SplashBloc(
      getIt<CheckSplashSeenUseCase>(),
      getIt<SetSplashSeenUseCase>(),
    ),
  );
}

void _initOnboardingDependencies() {
  final onboardingBox = getIt<HiveService>().getBox('onboardingBox');

  getIt.registerLazySingleton<OnboardingLocalDataSource>(
      () => OnboardingLocalDataSource(onboardingBox));

  getIt.registerLazySingleton<OnboardingLocalRepository>(
      () => OnboardingLocalRepository(getIt<OnboardingLocalDataSource>()));

  getIt.registerLazySingleton<CheckOnboardingSeenUseCase>(
      () => CheckOnboardingSeenUseCase(getIt<OnboardingLocalRepository>()));
  getIt.registerLazySingleton<SetOnboardingSeenUseCase>(
      () => SetOnboardingSeenUseCase(getIt<OnboardingLocalRepository>()));

  getIt.registerFactory<OnboardingBloc>(
    () => OnboardingBloc(
      getIt<CheckOnboardingSeenUseCase>(),
      getIt<SetOnboardingSeenUseCase>(),
    ),
  );
}

void _initLoginDependencies() {
  final loginBox = getIt<HiveService>().getBox('loginBox');

  getIt.registerLazySingleton<LoginLocalDataSource>(
      () => LoginLocalDataSource(loginBox));

  getIt.registerLazySingleton<LoginLocalRepository>(
      () => LoginLocalRepository(getIt<LoginLocalDataSource>()));

  getIt.registerLazySingleton<AuthenticateUserUseCase>(() =>
      AuthenticateUserUseCase(localRepository: getIt<LoginLocalRepository>()));

  getIt.registerFactory<LoginBloc>(
    () => LoginBloc(getIt<AuthenticateUserUseCase>()),
  );
}

void _initSignupDependencies() {
  final signupBox = getIt<HiveService>().getBox('signupBox');

  getIt.registerLazySingleton<SignupLocalDataSource>(
      () => SignupLocalDataSource(signupBox));

  getIt.registerLazySingleton<SignupLocalRepository>(
      () => SignupLocalRepository(getIt<SignupLocalDataSource>()));

  getIt.registerLazySingleton<RegisterUserUseCase>(() =>
      RegisterUserUseCase(localRepository: getIt<SignupLocalRepository>()));

  getIt.registerFactory<SignupBloc>(
    () => SignupBloc(getIt<RegisterUserUseCase>()),
  );
}
