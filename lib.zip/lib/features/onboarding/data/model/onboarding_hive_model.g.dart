// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'onboarding_hive_model.dart';

// **************************************************************************
// TypeAdapterGenerator
// **************************************************************************

class OnboardingHiveModelAdapter extends TypeAdapter<OnboardingHiveModel> {
  @override
  final int typeId = 1;

  @override
  OnboardingHiveModel read(BinaryReader reader) {
    final numOfFields = reader.readByte();
    final fields = <int, dynamic>{
      for (int i = 0; i < numOfFields; i++) reader.readByte(): reader.read(),
    };
    return OnboardingHiveModel(
      onboardingSeen: fields[0] as bool,
    );
  }

  @override
  void write(BinaryWriter writer, OnboardingHiveModel obj) {
    writer
      ..writeByte(1)
      ..writeByte(0)
      ..write(obj.onboardingSeen);
  }

  @override
  int get hashCode => typeId.hashCode;

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is OnboardingHiveModelAdapter &&
          runtimeType == other.runtimeType &&
          typeId == other.typeId;
}
