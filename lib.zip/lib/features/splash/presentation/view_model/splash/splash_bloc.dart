// import 'package:flutter_bloc/flutter_bloc.dart';
// import 'package:glownepal_mobile_app_5th_sem/features/splash/domain/use_case/check_splash_seen_usecase.dart';
// import 'package:glownepal_mobile_app_5th_sem/features/splash/domain/use_case/set_splash_seen_usecase.dart';

// import 'splash_event.dart';
// import 'splash_state.dart';

// class SplashBloc extends Bloc<SplashEvent, SplashState> {
//   final CheckSplashSeenUseCase checkSplashSeenUseCase;
//   final SetSplashSeenUseCase setSplashSeenUseCase;

//   SplashBloc(this.checkSplashSeenUseCase, this.setSplashSeenUseCase)
//       : super(SplashInitial()) {
//     on<CheckSplashSeenEvent>((event, emit) async {
//       final seen = await checkSplashSeenUseCase();
//       if (seen) {
//         emit(SplashSeen());
//       } else {
//         emit(SplashNotSeen());
//       }
//     });

//     on<SetSplashSeenEvent>((event, emit) async {
//       await setSplashSeenUseCase();
//       emit(SplashSeen());
//     });
//   }
// }
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:glownepal_mobile_app_5th_sem/features/splash/domain/use_case/check_splash_seen_usecase.dart';
import 'package:glownepal_mobile_app_5th_sem/features/splash/domain/use_case/set_splash_seen_usecase.dart';
import 'package:glownepal_mobile_app_5th_sem/features/splash/presentation/view_model/splash/splash_event.dart';
import 'package:glownepal_mobile_app_5th_sem/features/splash/presentation/view_model/splash/splash_state.dart';

class SplashBloc extends Bloc<SplashEvent, SplashState> {
  final CheckSplashSeenUseCase checkSplashSeenUseCase;
  final SetSplashSeenUseCase setSplashSeenUseCase;

  SplashBloc(this.checkSplashSeenUseCase, this.setSplashSeenUseCase)
      : super(SplashInitial()) {
    on<CheckSplashSeenEvent>((event, emit) async {
      final isSeen = await checkSplashSeenUseCase.call();
      if (isSeen) {
        emit(SplashSeen());
      } else {
        emit(SplashNotSeen());
      }
    });

    on<SetSplashSeenEvent>((event, emit) async {
      await setSplashSeenUseCase.call();
      emit(SplashSeen());
    });
  }
}
