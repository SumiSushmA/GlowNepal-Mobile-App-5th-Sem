abstract class SignupEvent {}

class SignupSubmitted extends SignupEvent {
  final String name;
  final String email;
  final String password;
  final String imagePath;

  SignupSubmitted({
    required this.name,
    required this.email,
    required this.password,
    required this.imagePath,
  });
}
