import 'package:glownepal_mobile_app_5th_sem/features/authentication/data/data_source/signup_datasource.dart';
import 'package:hive/hive.dart';

class SignupLocalDataSource implements ISignupDataSource {
  final Box box;

  SignupLocalDataSource(
    this.box,
  );

  @override
  Future<void> cacheUserData(
      String token, Map<String, dynamic> userData) async {
    await box.put('token', token);
    await box.put('userData', userData);
  }

  @override
  Future<String?> getCachedToken() async {
    return box.get('token');
  }

  @override
  Future<Map<String, dynamic>?> getCachedUserData() async {
    return box.get('userData');
  }

  @override
  Future<Map<String, dynamic>> registerUser(
      String name, String email, String password, String imagePath) {
    throw UnimplementedError("Local data source cannot register user");
  }
}
