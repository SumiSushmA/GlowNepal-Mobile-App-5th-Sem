import 'package:glownepal_mobile_app_5th_sem/features/authentication/data/data_source/login_datasource.dart';
import 'package:glownepal_mobile_app_5th_sem/features/authentication/domain/entity/login_entity.dart';
import 'package:glownepal_mobile_app_5th_sem/features/authentication/domain/repository/login_repository.dart';

class LoginLocalRepository implements LoginRepository {
  final ILoginDataSource localDataSource;

  LoginLocalRepository(this.localDataSource);

  @override
  Future<void> saveUserSession(String token, LoginEntity user) async {
    await localDataSource.cacheUserData(token, user.toMap());
  }

  @override
  Future<LoginEntity?> getCachedUserSession() async {
    final token = await localDataSource.getCachedToken();
    final userData = await localDataSource.getCachedUserData();

    if (token != null && userData != null) {
      return LoginEntity(token: token, userData: userData);
    }
    return null;
  }

  @override
  Future<Map<String, dynamic>> authenticateUser(String email, String password) {
    throw UnimplementedError("Local repository cannot authenticate user");
  }
}
