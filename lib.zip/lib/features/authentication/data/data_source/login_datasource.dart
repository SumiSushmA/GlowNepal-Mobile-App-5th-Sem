abstract class ILoginDataSource {
  Future<Map<String, dynamic>> authenticateUser(String email, String password);
  Future<void> cacheUserData(String token, Map<String, dynamic> userData);
  Future<String?> getCachedToken();
  Future<Map<String, dynamic>?> getCachedUserData();
}
