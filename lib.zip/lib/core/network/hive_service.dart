// import 'package:hive_flutter/hive_flutter.dart';
// import 'package:path_provider/path_provider.dart';

// import '../../features/authentication/data/model/login_hive_model.dart';
// import '../../features/authentication/data/model/signup_hive_model.dart';

// class HiveService {
//   Future<void> init() async {
//     // Initialize the Database
//     var directory = await getApplicationDocumentsDirectory();
//     var path = '\${directory.path}/glownepal.db';

//     // Create Database
//     Hive.init(path);

//     // Register Adapters
//     Hive.registerAdapter(LoginHiveModelAdapter());
//     Hive.registerAdapter(SignupHiveModelAdapter());
//   }

//   // Generic Methods
//   Future<void> addItem<T>(String boxName, String key, T item) async {
//     var box = await Hive.openBox<T>(boxName);
//     await box.put(key, item);
//   }

//   Future<void> deleteItem<T>(String boxName, String key) async {
//     var box = await Hive.openBox<T>(boxName);
//     await box.delete(key);
//   }

//   Future<List<T>> getAllItems<T>(String boxName) async {
//     var box = await Hive.openBox<T>(boxName);
//     return box.values.toList();
//   }

//   Future<T?> getItem<T>(String boxName, String key) async {
//     var box = await Hive.openBox<T>(boxName);
//     return box.get(key);
//   }
// }

import 'package:hive_flutter/hive_flutter.dart';
import 'package:path_provider/path_provider.dart';

class HiveService {
  Future<void> init() async {
    // Initialize Hive Database
    var directory = await getApplicationDocumentsDirectory();
    Hive.init(directory.path);

    // Open necessary boxes
    await Hive.openBox('splashBox');
    await Hive.openBox('onboardingBox');
    await Hive.openBox('loginBox');
    await Hive.openBox('signupBox');
  }

  Box getBox(String boxName) {
    return Hive.box(boxName);
  }
}
