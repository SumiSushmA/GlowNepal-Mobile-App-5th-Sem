abstract class SignupState {}

class SignupInitial extends SignupState {}

class SignupLoading extends SignupState {}

class SignupSuccess extends SignupState {
  final dynamic user;

  SignupSuccess({required this.user});
}

class SignupFailure extends SignupState {
  final String message;

  SignupFailure({required this.message});
}
