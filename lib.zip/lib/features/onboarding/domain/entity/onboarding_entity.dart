class OnboardingEntity {
  final bool onboardingSeen;

  OnboardingEntity({required this.onboardingSeen});
}
