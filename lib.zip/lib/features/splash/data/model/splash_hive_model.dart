import 'package:hive/hive.dart';

part 'splash_hive_model.g.dart';

@HiveType(typeId: 0)
class SplashHiveModel {
  @HiveField(0)
  final bool splashSeen;

  SplashHiveModel({required this.splashSeen});
}
