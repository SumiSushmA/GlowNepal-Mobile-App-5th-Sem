abstract class OnboardingState {}

class OnboardingInitial extends OnboardingState {}

class OnboardingSeen extends OnboardingState {}

class OnboardingNotSeen extends OnboardingState {}
